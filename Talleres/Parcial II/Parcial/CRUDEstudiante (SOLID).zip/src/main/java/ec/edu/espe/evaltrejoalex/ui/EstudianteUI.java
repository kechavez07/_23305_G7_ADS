package ec.edu.espe.evaltrejoalex.ui;


import ec.edu.espe.evaltrejoalex.controller.EstudianteController;
import ec.edu.espe.evaltrejoalex.model.Estudiante;

import java.util.List;
import java.util.Scanner;


/**
 * Clase Vista (V) que maneja la interfaz de usuario por consola.
 * Interactua con el usuario y muestra acciones o datos
 */
public class EstudianteUI {

    /**
     * Controlador (C) que maneja la lógica de negocio y acceso a datos.
     * Este controlador se encarga de las operaciones CRUD y la lógica de negocio.
     */
    private final EstudianteController estudianteController;
    /**
     * Scanner para leer la entrada del usuario desde la consola.
     * Utilizado para capturar las opciones y datos ingresados por el usuario.
     */
    private final Scanner scanner;

    /**
     * Constructor de la clase EstudianteUI.
     * Inicializa el controlador y el scanner.
     * @param estudianteController Controlador que maneja la lógica de negocio y acceso a datos.
     */
    public EstudianteUI(EstudianteController estudianteController) {
        this.estudianteController = estudianteController;
        this.scanner = new Scanner(System.in);
    }


    /**
     * Método que muestra el menú principal de la aplicación.
     * Permite al usuario seleccionar una opción para realizar operaciones CRUD sobre estudiantes.
     */
    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("-----------------------------------------------------");
            System.out.println("\n---     CRUD Estudiantes  ----Trejo Alex");
            System.out.println("1. Agregar Estudiante");
            System.out.println("2. Listar todos los Estudiantes");
            System.out.println("3. Actualizar Estudiante");
            System.out.println("4. Eliminar Estudiante");
            System.out.println("5. Buscar Estudiante por ID");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            // Manejo de excepciones para capturar entradas no numéricas
            try {
                opcion = Integer.parseInt(scanner.nextLine());
                switch (opcion) {
                    case 1: agregarEstudiante(); break;
                    case 2: listarEstudiantes(); break;
                    case 3: actualizarEstudiante(); break;
                    case 4: eliminarEstudiante(); break;
                    case 5: buscarEstudiante(); break;
                    case 0: System.out.println("Saliendo del programa... Vuelva pronto :)... "); break;
                    default: System.out.println("Opción no válida. Intente de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor, ingrese un número válido.");
                System.out.println("Este menú solo tiene opciones del 1 al 5");

                opcion = -1; // Para que el bucle continúe
            }

        } while (opcion != 0);
    }

    /**
     * Métodos privados que implementan las operaciones CRUD.
     * Cada método interactúa con el controlador para realizar la acción correspondiente.
     */

    /**
     * Método para agregar un nuevo estudiante.
     *  
     * Solicita al usuario los datos del estudiante y llama al controlador para crear el estudiante.
     */
    private void agregarEstudiante() {
        System.out.print("Ingrese nombres: ");
        String nombres = scanner.nextLine();
        System.out.print("Ingrese apellidos: ");
        String apellidos = scanner.nextLine();
        System.out.print("Ingrese edad: ");
        int edad = Integer.parseInt(scanner.nextLine());

        estudianteController.crearEstudiante(apellidos, nombres, edad);
        System.out.println("¡Estudiante agregado exitosamente!");
    }


    /**
     * Método para listar todos los estudiantes registrados.
     * 
     * Llama al controlador para obtener la lista de estudiantes y muestra sus detalles.
     */
    private void listarEstudiantes() {
        List<Estudiante> estudiantes = estudianteController.obtenerTodosLosEstudiantes();
        System.out.println("\n-------------------------------------------------");
        System.out.println("-------------- Lista de Estudiantes --------------");
        if (estudiantes.isEmpty()) {
            System.out.println("No hay estudiantes registrados.");
        } else {
            for (Estudiante e : estudiantes) {
                System.out.println(e.toString()); // Usando el método toString()
            }
        }
    }

    /**
     * Método para actualizar un estudiante existente.
     * 
     * Solicita al usuario el ID del estudiante a actualizar y los nuevos datos, luego llama al controlador para realizar la actualización.
     */
    private void actualizarEstudiante() {
        System.out.print("Ingrese el ID del estudiante a actualizar: ");
        int id = Integer.parseInt(scanner.nextLine());

        if (estudianteController.buscarEstudiantePorId(id) == null) {
            System.out.println("Error: No se encontró un estudiante con ese ID.");
            return;
        }

        System.out.print("Ingrese los nuevos nombres: ");
        String nuevosNombres = scanner.nextLine();
        System.out.print("Ingrese los nuevos apellidos: ");
        String nuevosApellidos = scanner.nextLine();
        System.out.print("Ingrese la nueva edad: ");
        int nuevaEdad = Integer.parseInt(scanner.nextLine());

        estudianteController.actualizarEstudiante(id, nuevosApellidos, nuevosNombres, nuevaEdad);
        System.out.println("¡Estudiante actualizado exitosamente!");
    }


    /**
     * Método para eliminar un estudiante existente.
     * 
     * Solicita al usuario el ID del estudiante a eliminar y llama al controlador para realizar la eliminación.
     */
    private void eliminarEstudiante() {
        System.out.print("Ingrese el ID del estudiante a eliminar: ");
        int id = Integer.parseInt(scanner.nextLine());

        if (estudianteController.buscarEstudiantePorId(id) == null) {
            System.out.println("Error: No se encontró un estudiante con ese ID.");
            return;
        }

        estudianteController.eliminarEstudiante(id);
        System.out.println("¡Estudiante eliminado exitosamente!");
    }


    /**
     * Método para buscar un estudiante por su ID.
     * 
     * Solicita al usuario el ID del estudiante a buscar y muestra sus detalles si se encuentra.
     */
    private void buscarEstudiante() {
        System.out.print("Ingrese el ID del estudiante a buscar: ");
        int id = Integer.parseInt(scanner.nextLine());
        Estudiante estudiante = estudianteController.buscarEstudiantePorId(id);
        if (estudiante != null) {
            System.out.println("--- Estudiante Encontrado ---");
            System.out.println(estudiante);
        } else {
            System.out.println("No se encontró ningún estudiante con el ID " + id);
        }
    }


}


