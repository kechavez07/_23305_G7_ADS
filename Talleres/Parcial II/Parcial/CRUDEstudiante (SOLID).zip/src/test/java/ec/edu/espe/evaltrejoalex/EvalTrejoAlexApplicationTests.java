package ec.edu.espe.evaltrejoalex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvalTrejoAlexApplicationTests {

	@Test
	void contextLoads() {
	}

}
