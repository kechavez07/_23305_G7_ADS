package ec.edu.espe.evaltrejoalex.dao;

import ec.edu.espe.evaltrejoalex.model.Estudiante;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;



/**
 * Implementación del repositorio de estudiantes.
 * Esta clase maneja la persistencia de datos en memoria.
 * Implementa la interfaz IEstudianteRepository.
 */
public class EstudianteDAO implements IEstudianteRepository {

    /**
     * Lista que simula una base de datos en memoria.
     * Almacena los objetos Estudiante.
     */
    private final List<Estudiante> estudiantes = new ArrayList<>();

    /**
     * Contador para generar IDs únicos y autoincrementales.
     * Utiliza AtomicInteger para asegurar la seguridad en entornos multihilo.
     */
    private static final AtomicInteger contadorId = new AtomicInteger(0);

    /**
     * Constructor de la clase EstudianteDAO.
     * Inicializa la lista con algunos datos de ejemplo.
     * Los IDs serán asignados automáticamente al agregar nuevos estudiantes.
     */
    public EstudianteDAO() {
        agregar(new Estudiante(0, "Pérez", "Ana", 20)); // ID será asignado automáticamente
        agregar(new Estudiante(0, "García", "Luis", 22));
    }


    /**
     * Método para agregar un nuevo estudiante.
     * Asigna un ID único y autoincremental al estudiante antes de agregarlo a la lista.
     * @param estudiante Objeto Estudiante a agregar.
     */
    @Override
    public void agregar(Estudiante estudiante) {
        // Asignar un nuevo ID único y autoincremental
        estudiante.setIdEstudiante(contadorId.incrementAndGet());
        estudiantes.add(estudiante);
    }


    /**
     * Método para obtener todos los estudiantes registrados.
     * @return Lista de estudiantes.
     */
    @Override
    public List<Estudiante> obtenerTodos() {
        return new ArrayList<>(estudiantes); // Devolver una copia para evitar modificaciones externas
    }


    /**
     * Método para buscar un estudiante por su ID.
     * @param id ID del estudiante a buscar.
     * @return Estudiante encontrado o null si no existe.
     */
    @Override
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getIdEstudiante() == id) {
                return e;
            }
        }
        return null; // No encontrado
    }


    /**
     * Método para actualizar un estudiante existente.
     * Busca el estudiante por ID y actualiza sus datos.
     * @param estudianteActualizado Objeto Estudiante con los nuevos datos.
     */
    @Override
    public void actualizar(Estudiante estudianteActualizado) {
        Estudiante estudianteExistente = buscarPorId(estudianteActualizado.getIdEstudiante());
        if (estudianteExistente != null) {
            estudianteExistente.setNombresEstudiante(estudianteActualizado.getNombresEstudiante());
            estudianteExistente.setApellidosEstudiante(estudianteActualizado.getApellidosEstudiante());
            estudianteExistente.setEdadEstudiante(estudianteActualizado.getEdadEstudiante());
        }
    }

    /**
     * Método para eliminar un estudiante por su ID.
     * Busca el estudiante por ID y lo elimina de la lista si existe.
     * @param id ID del estudiante a eliminar.
     */
    @Override
    public void eliminar(int id) {
        estudiantes.removeIf(e -> e.getIdEstudiante() == id);
    }





}



