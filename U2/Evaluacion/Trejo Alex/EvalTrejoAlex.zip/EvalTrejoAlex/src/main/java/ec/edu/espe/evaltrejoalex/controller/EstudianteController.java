package ec.edu.espe.evaltrejoalex.controller;

import ec.edu.espe.evaltrejoalex.dao.IEstudianteRepository;
import ec.edu.espe.evaltrejoalex.model.Estudiante;

import java.util.List;

/**
 * Clase de Servicio (Controlador ) maneja la lógica de negocio.
 * Coordina las operaciones entre la UI y el Repositorio.
 * Depende de la abstracción IEstudianteRepository (DIP).
 */
public class EstudianteController {

    private IEstudianteRepository estudianteRepository;

    /**
     * Constructor que inyecta la dependencia del repositorio.
     * @param estudianteRepository La implementación del DAO a utilizar.
     */
    public EstudianteController(IEstudianteRepository estudianteRepository) {
        this.estudianteRepository = estudianteRepository;
    }

    public void crearEstudiante(String apellidos, String nombres, int edad) {
        // Validaciones
        if (nombres == null || nombres.trim().isEmpty() || apellidos == null || apellidos.trim().isEmpty()) {
            System.out.println("Error: Nombres y apellidos no pueden estar vacíos.");
            return;
        }
        // El ID autogenerado por el repositorio.
        Estudiante nuevoEstudiante = new Estudiante(0, apellidos, nombres, edad);
        estudianteRepository.agregar(nuevoEstudiante);
    }

    /**
     * Método para obtener todos los estudiantes registrados.
     * 
     * @return Lista de estudiantes.
     */
    public List<Estudiante> obtenerTodosLosEstudiantes() {
        return estudianteRepository.obtenerTodos();
    }

    /**
     * Método para buscar un estudiante por su ID.
     * 
     * @param id ID del estudiante a buscar.
     * @return Estudiante encontrado o null si no existe.
     */
    public Estudiante buscarEstudiantePorId(int id) {
        return estudianteRepository.buscarPorId(id);
    }


    /**
     * Método para actualizar un estudiante existente.
     * 
     * @param id ID del estudiante a actualizar.
     * @param nuevosApellidos Nuevos apellidos del estudiante.
     * @param nuevosNombres Nuevos nombres del estudiante.
     * @param nuevaEdad Nueva edad del estudiante.
     */
    public void actualizarEstudiante(int id, String nuevosApellidos, String nuevosNombres, int nuevaEdad) {
        Estudiante estudianteActualizado = new Estudiante(id, nuevosApellidos, nuevosNombres, nuevaEdad);
        estudianteRepository.actualizar(estudianteActualizado);
    }


    /**
     * Método para eliminar un estudiante por su ID.
     * 
     * @param id ID del estudiante a eliminar.
     */
    public void eliminarEstudiante(int id) {
        estudianteRepository.eliminar(id);
    }

}
