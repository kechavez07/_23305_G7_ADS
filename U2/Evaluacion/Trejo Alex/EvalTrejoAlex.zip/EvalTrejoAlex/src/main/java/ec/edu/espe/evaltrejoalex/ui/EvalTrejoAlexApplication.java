package ec.edu.espe.evaltrejoalex.ui;

import ec.edu.espe.evaltrejoalex.controller.EstudianteController;
import ec.edu.espe.evaltrejoalex.dao.EstudianteDAO;
import ec.edu.espe.evaltrejoalex.dao.IEstudianteRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada de la aplicación.
 * Responsable de la creación e inyección de dependencias.
 */
@SpringBootApplication
public class EvalTrejoAlexApplication {

	public static void main(String[] args) {

		// Inicia la aplicación Spring Boot
		// Esto configura el contexto de la aplicación y permite la inyección de dependencias
		SpringApplication.run(EvalTrejoAlexApplication.class, args);

		// Crea una instancia del repositorio de estudiantes
		IEstudianteRepository repository = new EstudianteDAO();

		// Crea una instancia del controlador de estudiantes, inyectando el repositorio
		// El controlador maneja la lógica de negocio y las operaciones CRUD
		EstudianteController service = new EstudianteController(repository);

		// Crea una instancia de la interfaz de usuario, inyectando el controlador
		// La interfaz de usuario maneja la interacción con el usuario y muestra el menú
		// Permite al usuario realizar operaciones CRUD sobre estudiantes
		EstudianteUI ui = new EstudianteUI(service);


		ui.mostrarMenu();




	}

}




