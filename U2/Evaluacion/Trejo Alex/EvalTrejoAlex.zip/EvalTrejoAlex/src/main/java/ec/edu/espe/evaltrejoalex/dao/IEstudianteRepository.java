package ec.edu.espe.evaltrejoalex.dao;

import ec.edu.espe.evaltrejoalex.model.Estudiante;

import java.util.List;

/**
 * Interfaz del Repositorio (DAO) que define las operaciones de persistencia
 * para la entidad Estudiante.
 * Aplica el Principio de Inversión de Dependencias (DIP).
 */
public interface IEstudianteRepository {
    /**
     * Guarda un nuevo estudiante.
     * @param estudiante El estudiante a agregar.
     */
    void agregar(Estudiante estudiante);

    /**
     * Devuelve una lista con todos los estudiantes.
     * @return Lista de todos los estudiantes.
     */
    List<Estudiante> obtenerTodos();

    /**
     * Busca un estudiante por su ID.
     * @param id El ID del estudiante a buscar.
     * @return El estudiante encontrado o null si no existe.
     */
    Estudiante buscarPorId(int id);

    /**
     * Actualiza los datos de un estudiante existente.
     * @param estudianteActualizado El estudiante con los nuevos datos.
     */
    void actualizar(Estudiante estudianteActualizado);

    /**
     * Elimina un estudiante por su ID.
     * @param id El ID del estudiante a eliminar.
     */
    void eliminar(int id);
}