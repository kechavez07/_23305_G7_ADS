package ec.edu.espe.evaltrejoalex.model;

public class Estudiante {
    private int idEstudiante;
    private String apellidosEstudiante;
    private String nombresEstudiante;
    private int edadEstudiante;

    /**
     * Constructor para inicializar un objeto Estudiante.
     *
     * @param id        Identificador único del estudiante.
     * @param apellidos Apellidos del estudiante.
     * @param nombres   Nombres del estudiante.
     * @param edad      Edad del estudiante.
     */
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.idEstudiante = id;
        this.apellidosEstudiante = apellidos;
        this.nombresEstudiante = nombres;
        this.edadEstudiante = edad;
    }

    // --- Getters y Setters ---

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public String getApellidosEstudiante() {
        return apellidosEstudiante;
    }

    public void setApellidosEstudiante(String apellidosEstudiante) {
        this.apellidosEstudiante = apellidosEstudiante;
    }

    public String getNombresEstudiante() {
        return nombresEstudiante;
    }

    public void setNombresEstudiante(String nombresEstudiante) {
        this.nombresEstudiante = nombresEstudiante;
    }

    public int getEdadEstudiante() {
        return edadEstudiante;
    }

    public void setEdadEstudiante(int edadEstudiante) {
        this.edadEstudiante = edadEstudiante;
    }

    /**
     *
     * @return una cadena de texto formateada con los datos del estudiante.
     */
    @Override
    public String toString() {
        return "ID: " + idEstudiante +
                " | Nombres: " + nombresEstudiante +
                " | Apellidos: " + apellidosEstudiante +
                " | Edad: " + edadEstudiante;
    }

}
