import controller.EstudianteController;
import ui.EstudianteUI;

public class Main {
    public static void main(String[] args) {


        /// En esta clase del Main solo llamos a la vista
        EstudianteUI ui = new EstudianteUI();
        ui.menu();




    }

}