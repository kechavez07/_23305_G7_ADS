package ui;
import controller.EstudianteController;
import java.util.Scanner;
/**
 *En este la vista lo que estoy haciendo es creando un menu por consola
 * importando solo el controller ya que esta clase me permite accesder
 * a sus metodos que ya hacen la logica
 */
public class EstudianteUI {
    public  void menu(){
        EstudianteController c = new EstudianteController();
        //Seccion para agregar estudiantes al inicio
        c.crearEstudiante(1,"Chavez Oscullo","Kleber Enrique",1);
        c.crearEstudiante(2,"Lino Oscullo","Pedro Enrique",2);
        c.crearEstudiante(3,"Perez Oscullo","Juan Enrique",1);

        System.out.println("1. Crear Estudiante");
        System.out.println("2. Buscar Estudiante");
        System.out.println("3. Mostrar Estudiantes");
        System.out.println("4. Eliminar Estudiante");
        System.out.println("5. Actualizar Estudiante");
        System.out.println("Ingrese el Numero de la opcion que desea");
        int opcion=0;
        int id=0;
        Scanner scanner = new Scanner(System.in);
        opcion = scanner.nextInt();

        switch (opcion){
            case 1:
                agregarEstudiante(c);
                menu();
                break;
            case 2:
                System.out.println("Ingrese el id del estudiante");
                id = scanner.nextInt();
                c.buscarEstudiante(id);
                menu();
                break;
            case 3:
                c.obtenerTodos();
                menu();
                break;
            case 4:
                System.out.println("Ingrese el id del estudiante");
                id = scanner.nextInt();
                c.eliminarEstudiante(id);
                menu();
                break;
            case 5:
                c.modificar();
                menu();
                break;
        }
    }
    public void agregarEstudiante(EstudianteController c) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese id del estudiante:");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Ingrese nombre:");
        String nombre = scanner.nextLine();
        scanner.nextLine();

        System.out.println("Ingrese apellido:");
        String apellido = scanner.nextLine();
        scanner.nextLine();

        System.out.println("Ingrese edad:");
        int edad = scanner.nextInt();
        scanner.nextLine();

        c.crearEstudiante(id, nombre, apellido, edad);

        System.out.println("Estudiante registrado con éxito.");
    }

}
