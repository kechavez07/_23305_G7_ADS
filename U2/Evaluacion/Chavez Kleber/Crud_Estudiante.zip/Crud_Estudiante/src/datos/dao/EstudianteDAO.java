package datos.dao;
import java.util.ArrayList;
import java.util.List;
import datos.model.Estudiante;
/**
*En este DAO separamos todo el codigo que sea relacionado con el
 * Acceso a la data en este caso es un array pero perfectamente
 * podria hacer una base de datos en la nube
 */

public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();

    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    public List<Estudiante> listar() {
        return estudiantes;
    }

    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }
    public void eliminar(Estudiante e) {
        estudiantes.remove(e);
    }

    public void modificar(Estudiante e) {
        estudiantes.set(estudiantes.indexOf(e), e);
    }


}
