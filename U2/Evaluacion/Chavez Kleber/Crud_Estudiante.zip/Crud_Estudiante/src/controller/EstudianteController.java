package controller;
import datos.dao.EstudianteDAO;
import datos.model.Estudiante;
import java.util.List;
import java.util.Scanner;
/**
 *En este Controlador creamos todas las duncionalidades de nuestro CRUD
 * para que de esta froma solo tengamos la logica de nuestro programa en esta seccion
 */

public class EstudianteController {
    private EstudianteDAO dao = new EstudianteDAO();

    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }

    public void obtenerTodos() {
        List<Estudiante> estudiantes = dao.listar();
        for (Estudiante e : estudiantes) {
            System.out.println(e);
        }
    }

    public void buscarEstudiante(int id) {
        System.out.println(dao.buscarPorId(id)) ;
    }
    public void eliminarEstudiante(int id) {
        Estudiante e = dao.buscarPorId(id);
        dao.eliminar(e);
    }
    public void modificar() {
        System.out.println("Ingrese el id del estudiante a modificar");
        System.out.println("Ingrese de nuevo todos los datos y en el proceso modifique el que dea editar");

        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese id del estudiante:");
        int id = scanner.nextInt();

        System.out.println("Ingrese nombre:");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese apellido:");
        String apellido = scanner.nextLine();

        System.out.println("Ingrese edad:");
        int edad = scanner.nextInt();
        scanner.nextLine(); // limpiar buffer

        Estudiante e = dao.buscarPorId(id);
        e.setApellidos(apellido);
        e.setNombres(nombre);
        e.setEdad(edad);
        dao.modificar(e);
    }

}
